"""Rule-owned recommendation direction and skill classifications."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr, model_validator

from app.eligibility.contracts import EvidenceSpan


TargetDirection = Literal[
    "ai_application", "backend", "computer_vision", "data", "frontend",
    "test_development", "devops", "security",
]
DetectedDirection = Literal[TargetDirection, "other"]
DirectionStatus = Literal["aligned", "uncertain", "unrelated", "not_requested"]
SkillImportance = Literal["core", "bonus", "unclassified"]


class DirectionFit(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: DirectionStatus
    detected_directions: list[DetectedDirection] = Field(default_factory=list)
    reason: StrictStr = Field(min_length=1)
    evidence: list[EvidenceSpan] = Field(default_factory=list)

    @model_validator(mode="after")
    def verify_decision(self):
        if len(self.detected_directions) != len(set(self.detected_directions)):
            raise ValueError("A detected direction must be unique.")
        if self.status in {"aligned", "unrelated"}:
            if not self.evidence or not self.detected_directions:
                raise ValueError("A known direction requires a role and a source quote.")
        elif self.detected_directions or (self.status == "not_requested" and self.evidence):
            raise ValueError("An unknown or unrequested direction cannot assert a detected role.")
        if any(span.field not in {"title", "description"} for span in self.evidence):
            raise ValueError("A role quote must come from the job title or description.")
        return self


class SkillRequirement(BaseModel):
    model_config = ConfigDict(extra="forbid")
    skill: StrictStr = Field(min_length=1)
    importance: SkillImportance
    matched: StrictBool
    evidence: list[EvidenceSpan] = Field(default_factory=list)

    @model_validator(mode="after")
    def verify_strength(self):
        if self.importance != "unclassified" and not any(span.field == "description" for span in self.evidence):
            raise ValueError("A core or bonus skill requires a source clause in the description.")
        if any(span.field not in {"title", "description"} for span in self.evidence):
            raise ValueError("A skill quote must come from the job title or description.")
        return self
