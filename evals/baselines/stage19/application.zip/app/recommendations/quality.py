"""Finite rules for role fit, quoted skill importance, and recommendation order."""

from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
import re

from app.eligibility.contracts import EvidenceSpan
from app.recommendations.quality_contracts import (
    DetectedDirection, DirectionFit, SkillRequirement, TargetDirection,
)
from app.schemas.job_response import JobRead
from app.services.skill_vocabulary import SKILL_ALIASES, normalize_skill


_ROLE_SUFFIX = r"(?:开发|研发|工程师|实习生|实习岗|技术员|岗位|[／/与和、&])"
_TITLE_PATTERNS: dict[DetectedDirection, re.Pattern] = {
    "ai_application": re.compile(r"(?:AI|人工智能|大模型|LLM)\s*应用\s*(?:开发|研发|工程师)|(?:智能体|(?:AI\s*)?Agent|LLM|RAG|大模型)\s*(?:应用)?\s*(?:开发|研发|工程师)|\b(?:AI application|LLM|AI agent)\s+(?:developer|engineer)", re.I),
    "backend": re.compile(r"(?:后端|后台|服务端)\s*" + _ROLE_SUFFIX + r"|(?<![a-z])back[ -]?end\s+(?:software\s+)?(?:developer|engineer|intern)", re.I),
    "computer_vision": re.compile(r"(?:计算机视觉|机器视觉|视觉算法|图像算法|CV\s*算法|CV(?=\s*工程师))\s*(?:方向|算法)?\s*(?:开发|研发|工程师|实习生|[／/与和、&])|\bcomputer vision\s+(?:research|engineer|developer|intern)", re.I),
    "data": re.compile(r"(?:大数据|数据)\s*(?:开发|工程师|分析(?:师|工程师|实习生|岗|[／/与和、&]|$)|研发)|\bdata\s+(?:engineer|analyst|analytics\s+engineer)", re.I),
    "frontend": re.compile(r"前端\s*" + _ROLE_SUFFIX + r"|(?<![a-z])front[ -]?end\s+(?:software\s+)?(?:developer|engineer|intern)", re.I),
    "test_development": re.compile(r"测试开发|测试研发|自动化测试(?:工程师|实习生|开发|岗)|(?:软件|接口)测试(?:工程师|实习生|岗)|\b(?:test automation|software test|QA automation)\s+(?:engineer|developer|intern)|\bSDET\b", re.I),
    "devops": re.compile(r"运维\s*(?:开发|研发|工程师|实习生|岗)|(?<![a-z])(?:DevOps|SRE)(?=\s*(?:工程师|实习生|岗|engineer|developer|intern|[／/与和、&]|$))", re.I),
    "security": re.compile(r"(?:信息|网络|应用|数据)?安全\s*(?:开发|研发|工程师)|\b(?:security engineer|security developer)", re.I),
}
_OTHER_ROLE = re.compile(
    r"(?:公关|公共关系|营销|品牌传播|市场推广|市场营销|市场运营|销售|人力资源)\s*(?:策划|运营)?\s*(?:经理|实习生|岗|专员|主管|顾问|代表|助理|总监|$)"
    r"|(?:产品|项目)\s*(?:经理|管理(?:实习生|岗|专员|工程师))|生物医学工程师"
    r"|\b(?:product manager|project manager|marketing (?:specialist|intern|manager)|public relations (?:specialist|intern|manager))\b", re.I,
)
# A generic title can be clarified by an explicit responsibility. Mentions of
# tools, degree subjects, job requirements, and collaboration partners do not suffice.
_DUTY_ACTION = r"(?:负责|承担|参与)"
_DUTY_SUBJECT = re.compile(r"(?:(?:本岗位|本职位|该岗位|该职位|你|您|实习生)\s*)?(?:(?:将|主要|独立)\s*)*")
_DUTY_PATTERNS: dict[DetectedDirection, re.Pattern] = {
    "ai_application": re.compile(_DUTY_ACTION + r"(?:开发|搭建|构建)?\s*(?:AI|人工智能|大模型|LLM|智能体|Agent|RAG)\s*(?:应用|系统|平台)(?:的)?(?:开发|研发|建设)|" + _DUTY_ACTION + r"(?:开发|构建|搭建)\s*(?:AI|大模型|LLM|智能体|Agent|RAG)\s*(?:应用|系统|平台)", re.I),
    "backend": re.compile(_DUTY_ACTION + r"(?:开发|维护|设计)?\s*(?:后端|后台|服务端)(?:服务|接口|系统|平台)?(?:的)?(?:设计|开发|研发|维护)|" + _DUTY_ACTION + r"(?:开发|维护)\s*(?:后端|服务端)(?:服务|接口|系统)"),
    "frontend": re.compile(_DUTY_ACTION + r"(?:Web\s*)?前端(?:页面|应用|系统)?(?:的)?(?:开发|研发)|" + _DUTY_ACTION + r"开发(?:Web\s*)?前端(?:页面|应用|系统)", re.I),
    "computer_vision": re.compile(_DUTY_ACTION + r"(?:研发|开发)?(?:计算机视觉|机器视觉|图像识别|图像分割|目标检测|视觉算法)(?:算法|系统)?(?:的)?(?:研发|开发|优化)|" + _DUTY_ACTION + r"(?:研发|开发)(?:计算机视觉|图像识别|图像分割|目标检测)(?:算法|系统)"),
    "data": re.compile(_DUTY_ACTION + r"(?:建设|开发|搭建)?(?:数据仓库|数仓|数据管道|ETL任务)(?:的)?(?:开发|建设|维护)|" + _DUTY_ACTION + r"(?:开发|搭建)(?:数据仓库|数仓|数据管道)", re.I),
    "test_development": re.compile(_DUTY_ACTION + r"(?:测试框架|自动化测试平台|自动化测试框架)(?:的)?(?:开发|建设)|" + _DUTY_ACTION + r"(?:开发|搭建)(?:自动化测试框架|自动化测试平台)"),
    "devops": re.compile(_DUTY_ACTION + r"(?:构建|维护|搭建)\s*(?:CI/CD|持续集成)(?:流水线|平台)", re.I),
    "security": re.compile(_DUTY_ACTION + r"(?:安全平台|安全检测引擎)(?:的)?(?:开发|研发)|" + _DUTY_ACTION + r"(?:开发|研发)(?:安全平台|安全检测引擎)"),
}
_DIRECTION_NAMES = {
    "ai_application": "AI 应用开发", "backend": "后端开发", "computer_vision": "计算机视觉",
    "data": "数据开发／分析", "frontend": "前端开发", "test_development": "测试开发",
    "devops": "运维／DevOps", "security": "安全研发", "other": "其他职能",
}


def _span(field, source: str, start: int, end: int) -> EvidenceSpan:
    return EvidenceSpan(field=field, text=source[start:end], start=start, end=end)


def evaluate_direction(job: JobRead, targets: Sequence[TargetDirection]) -> DirectionFit:
    if not targets:
        return DirectionFit(status="not_requested", reason="本次未限定岗位方向。")
    directions: list[DetectedDirection] = []
    evidence: list[EvidenceSpan] = []
    title_parts = [part for part in re.split(r"[（）()，,。；;\n]", job.title)
                   if not _AMBIGUOUS.search(part) and not re.search(r"非(?:AI|后端|前端|开发|研发|技术)|(?:经验|背景)(?:者)?优先", part, re.I)]
    has_other_role = any(_OTHER_ROLE.search(part) for part in title_parts)
    if has_other_role:
        # In "AI产品经理", AI names the product. Only an explicitly separate
        # technical role, e.g. "后端开发／产品经理", can also count.
        title_parts = [role for part in title_parts for role in re.split(r"[/／|｜]", part)
                       if not _OTHER_ROLE.search(role)]
    directions = [direction for direction, pattern in _TITLE_PATTERNS.items()
                  if any(pattern.search(part) for part in title_parts)]
    if has_other_role:
        directions.append("other")
    if directions:
        evidence.append(_span("title", job.title, 0, len(job.title)))
    else:
        for clause in _clauses(job.description):
            if (clause.section in {"core", "bonus", "other"} or _AMBIGUOUS.search(clause.quote.text)
                    or re.search(r"(?:曾经?|有过|要求|经验|优先|团队负责|部门负责)", clause.quote.text)):
                continue
            # Match the task assigned to the applicant. Verbs describing a
            # colleague ("与负责后端开发的同事协作") do not assign that role.
            task_start = _DUTY_SUBJECT.match(clause.quote.text).end()
            for direction, pattern in _DUTY_PATTERNS.items():
                if direction not in directions and pattern.match(clause.quote.text, task_start):
                    directions.append(direction)
                    if clause.quote not in evidence:
                        evidence.append(clause.quote)
    if not directions:
        return DirectionFit(status="uncertain", reason="岗位名称和职责未明确对应的技术方向。",
                            evidence=[_span("title", job.title, 0, len(job.title))] if job.title.strip() else [])
    aligned = bool(set(targets).intersection(directions))
    labels = "、".join(_DIRECTION_NAMES[direction] for direction in directions)
    return DirectionFit(status="aligned" if aligned else "unrelated", detected_directions=directions,
                        reason=f"原文明确的岗位方向为{labels}，" + ("与你选择的方向一致。" if aligned else "与本次选择的方向不同。"),
                        evidence=evidence)


_HEADINGS = {
    "bonus": r"加分项(?:目)?|加分条件|优先条件|优先考虑条件|优选条件|锦上添花|preferred qualifications|nice[- ]to[- ]haves?|bonus(?: skills)?",
    "core": r"任职要求|任职资格|岗位要求|职位要求|技能要求|必备技能|必备条件|基本要求|技术要求|required (?:qualifications|skills)|requirements|qualifications|must[- ]haves?",
    "duty": r"岗位职责|工作职责|岗位描述|职责描述|工作内容|职位描述|岗位内容|职责|responsibilities|job description",
    "other": r"职位福利|岗位福利|福利待遇|团队介绍|公司介绍|招聘流程|benefits|about us",
}
_HEADING = re.compile(r"(?:" + "|".join(f"(?P<{name}>{words})" for name, words in _HEADINGS.items())
                      + r")\s*(?:[:：]\s*|$)", re.I)
_CORE = re.compile(r"必须|必备|需要掌握|熟练|熟悉|掌握|精通|要求具备|须具备|\b(?:required|must|proficien(?:t|cy)|expertise|fluent)\b", re.I)
_BONUS = re.compile(r"优先|加分|更佳|最好|优选|\b(?:preferred|desirable|optional|bonus|nice[- ]to[- ]have|a plus)\b", re.I)
_AMBIGUOUS = re.compile(r"不(?:必|需|要求|强制|限于|限定|熟悉|熟练|掌握|会|是|属于|作为|负责|承担|涉及|参与|从事)|无需|无须|不限|并非|非(?:必[需须备]|硬性|强制)|无.{0,20}经验.{0,5}(?:可|也行)|或|任选|任意(?:一|两|二|多)|至少(?:一|1)种|二选一|其中之一|择一|\b(?:or|either|one of|not|no)\b", re.I)
_SENTENCE_END = re.compile(r"[。；;！!?？\r\n]+|(?<=[a-zA-Z])\.(?=\s|$)")
_BULLET = re.compile(r"^(?:[-•]\s+|\d{1,2}[、.)）-]\s*)")


@dataclass(frozen=True)
class _Clause:
    quote: EvidenceSpan
    section: str | None
    heading: EvidenceSpan | None


def _clauses(source: str) -> Iterator[_Clause]:
    section = None
    heading = None
    offset = 0
    for separator in _SENTENCE_END.finditer(source + "\n"):
        end = separator.start()
        raw = source[offset:end]
        start = offset
        offset = separator.end()
        text = raw.strip()
        if not text:
            continue
        start += raw.index(text)
        bullet = _BULLET.match(text)
        if bullet:
            start += bullet.end()
            text = source[start:end].strip()
        label = _HEADING.match(text)
        if label:
            section = label.lastgroup
            heading = _span("description", source, start, start + label.end())
            start += label.end()
            text = source[start:end].strip()
        if text:
            start = source.index(text, start, end)
            yield _Clause(_span("description", source, start, start + len(text)), section, heading)


@lru_cache(maxsize=512)
def _skill_pattern(skill: str) -> re.Pattern:
    aliases = {skill, *(alias for alias, canonical in SKILL_ALIASES.items() if canonical.casefold() == skill.casefold())}
    words = [r"\s+".join(re.escape(token) for token in value.split()) for value in sorted(aliases, key=len, reverse=True)]
    return re.compile(r"(?<![a-zA-Z0-9_])(?:" + "|".join(words) + r")(?![a-zA-Z0-9_+#])", re.I)


def _skill_clauses(clause: _Clause) -> Iterator[_Clause]:
    """Split independent conditions at commas, keeping skill lists and alternatives together."""
    text = clause.quote.text
    if re.search(r"任选|至少(?:一|1)种|其中之一|任意一|\bone of\b", text, re.I):
        yield clause
        return
    start = 0
    for comma in re.finditer(r"[,，、]", text):
        left = text[start:comma.start()]
        following = text[comma.end():]
        right = re.split(r"[,，]", following, maxsplit=1)[0].strip()
        # A new predicate starts its own scope; a comma in a list does not.
        if not (re.match(r"(?:但|然而|but\b|且须|并须|熟悉|熟练|掌握|精通|要求|须|需具备|必须|有.+(?:经验|背景)|加分|优先|不要求|无需)", right, re.I)
                or (comma.group() != "、" and (_CORE.search(left) or _BONUS.search(left))
                    and (_CORE.search(right) or _BONUS.search(right)))):
            continue
        if left.strip():
            yield _subclause(clause, start, comma.start())
        start = comma.end()
    if text[start:].strip():
        yield _subclause(clause, start, len(text))


def _subclause(clause: _Clause, start: int, end: int) -> _Clause:
    sub = EvidenceSpan(field="description", text=clause.quote.text[start:end],
                       start=clause.quote.start + start, end=clause.quote.start + end)
    return _Clause(sub, clause.section, clause.heading)


def _strength(clause: _Clause, mentions: int) -> str:
    text = clause.quote.text
    if _AMBIGUOUS.search(text) or (mentions > 1 and re.search(r"[/／]", text)):
        return "ambiguous"
    if _BONUS.search(text) or clause.section == "bonus":
        return "bonus"
    if clause.section in {"duty", "other"}:
        return "mention"
    if re.search(r"(?:负责|参与|协助|将使用|工作中|we use|you will)", text, re.I):
        return "mention"
    if _CORE.search(text) or clause.section == "core":
        return "core"
    return "mention"


def classify_skill_requirements(job: JobRead, detected_skills: list[str], candidate_skills: list[str]) -> list[SkillRequirement]:
    patterns = [(skill, _skill_pattern(skill)) for skill in detected_skills]
    covered = {normalize_skill(skill).casefold() for skill in candidate_skills}
    observations: dict[str, list[tuple[str, list[EvidenceSpan]]]] = {skill: [] for skill in detected_skills}
    for clause in _clauses(job.description):
        for part in _skill_clauses(clause):
            present = [skill for skill, pattern in patterns if pattern.search(part.quote.text)]
            strength = _strength(part, len(present))
            quotes = [part.heading, part.quote] if part.heading is not None else [part.quote]
            for skill in present:
                observations[skill].append((strength, quotes))
    results = []
    for skill, pattern in patterns:
        mentions = observations[skill]
        strengths = {strength for strength, _ in mentions} - {"mention"}
        importance = next(iter(strengths)) if strengths in ({"core"}, {"bonus"}) else "unclassified"
        evidence = []
        for strength, quotes in mentions:
            if importance != "unclassified" and strength != importance:
                continue
            for quote in quotes:
                if quote not in evidence:
                    evidence.append(quote)
        if not evidence and pattern.search(job.title):
            evidence = [_span("title", job.title, 0, len(job.title))]
        results.append(SkillRequirement(skill=skill, importance=importance,
                                        matched=normalize_skill(skill).casefold() in covered, evidence=evidence))
    return results


def quality_rank_key(item) -> tuple:
    def coverage(importance: str) -> Fraction:
        skills = [entry for entry in item.skill_requirements if entry.importance == importance]
        return Fraction(sum(entry.matched for entry in skills), len(skills)) if skills else Fraction(-1)

    return (0 if item.eligibility.overall == "met" else 1,
            1 if item.direction_fit.status == "uncertain" else 0,
            -coverage("core"), -coverage("bonus"), -item.match_score, -len(item.matched_skills), item.job.id)
